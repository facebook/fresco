/*
 * This file provided by Facebook is for non-commercial testing and evaluation
 * purposes only.  Facebook reserves all rights not expressly granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * FACEBOOK BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.facebook.fresco101;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

  private ImageView mImageView;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    mImageView = (ImageView) findViewById(R.id.image_view);
    // Events on EditText
    final EditText editText = (EditText) findViewById(R.id.uri_edit_text);
    editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override
      public boolean onEditorAction(TextView view, int actionId, KeyEvent keyEvent) {
        final boolean isEnterKeyDown = (actionId == EditorInfo.IME_NULL) &&
                                               (keyEvent.getAction() == KeyEvent.ACTION_DOWN);
        if (isEnterKeyDown || actionId == EditorInfo.IME_ACTION_DONE) {
          updateImageView(Uri.parse(view.getText().toString()));
        }
        return false;
      }
    });
    findViewById(R.id.clear_uri)
            .setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                editText.getText().clear();
              }
            });
  }

  private void updateImageView(Uri uri) {
    AsyncTask<Uri, Void, Bitmap> task = new AsyncTask<Uri, Void, Bitmap>() {
      @Override
      protected Bitmap doInBackground(Uri... uris) {
        InputStream inputStream = null;
        Bitmap bitmap = null;
        try {
          bitmap = fetchBitmap(uris[0]);
        } catch (Exception e) {
          // Head in the sand!
        } finally {
          if (inputStream != null) {
            try {
              inputStream.close();
            } catch (IOException e) {
              // Head in the sand!
            }
          }
        }
        return bitmap;
      }

      @Override
      protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        if (bitmap != null) {
          mImageView.setImageBitmap(bitmap);
        } else {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mImageView.setImageDrawable(getResources()
                .getDrawable(R.drawable.error_icon, getTheme()));
          } else {
            mImageView.setImageDrawable(getResources().getDrawable(R.drawable.error_icon));
          }
        }
      }
    };
    task.execute(uri);
  }


  private Bitmap fetchBitmap(Uri uri) throws IOException {
    Bitmap bitmap = null;
    try {
      final URL url = new URL(uri.toString());
      InputStream urlConnection = url.openStream();
      bitmap = BitmapFactory.decodeStream(urlConnection);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return bitmap;
  }
}
